//
//  TiHealthkit.h
//  ti.healthkit
//
//  Created by Jason Sultana
//  Copyright (c) 2020 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiHealthkit.
FOUNDATION_EXPORT double TiHealthkitVersionNumber;

//! Project version string for TiHealthkit.
FOUNDATION_EXPORT const unsigned char TiHealthkitVersionString[];

#import "TiHealthkitModuleAssets.h"
